# Handoff: QUICKDRAW — multiplayer drawing game (OCaml + Graphics)

## Overview
A 2–4 player game: everyone gets the same random dictionary word, draws it on a coarse pixel grid against a shared timer (no live view of opponents), then players rank each other's drawings. Score = vote points + speed bonus (+ optional easter-egg bonus). Optional sabotage layer: a player can temporarily lock a color for an opponent.

## About the Design Files
`Drawing Game Storyboard.dc.html` is a **design reference built in HTML** — a storyboard of six screens, not code to port. The task is to **recreate these screens in OCaml using the `Graphics` library** (`fill_rect`, `fill_circle`, `draw_string`, `moveto/lineto`, `wait_next_event`), following the measurements and colors below. The storyboard shows screens at 60% scale; all numbers in this README are the real 100% values.

## Fidelity
**Low-fidelity wireframes** — layout, flow, and information hierarchy are the contract. Exact pixel positions may shift, but keep: the flat 3-color-on-cream palette, 2px black borders with hard offset "shadows" (a second filled rect offset +3,+3 in black behind the box — Graphics has no real shadows), monospace-feel fixed font, and the timer as the loudest element on the drawing screen.

## Design Tokens
Window: fixed **800×600**. Colors as OCaml ints (`Graphics.rgb`):
- Ground (screen bg): `#F5EAD8` — rgb 245 234 216
- Ink (text/borders): `#201E1D` — rgb 32 30 29
- Accent / primary buttons / timer: `#C67139` — rgb 198 113 57
- Accent 2 / confirm actions: `#7A8A5E` — rgb 122 138 94
- Muted text: `#9C8C72`; disabled fill: `#E8D9C0`
- Extra palette colors for drawing: `#E8B23A` (yellow), `#4A6FA5` (blue), plus ink, accent, accent-2, white
- Buttons: filled rect + 2px ink border + 3px offset ink shadow, bold text, all-caps

## Screens / Views (in flow order)

### 1a — Title & Lobby
- Purpose: connect players, show socket state, host starts the round.
- Layout: title "QUICKDRAW" top-left (large, with +3/+3 accent offset echo behind the text); tagline under it in accent-2; a bordered player-list box (4 rows); server address line; START ROUND button bottom-left.
- Each player row: 12px status square (green `#7A8A5E` = ready, orange = connecting, sand = empty), name, right-aligned bordered tag (HOST · READY / READY / CONNECTING… in orange / "— open slot —" in muted).
- START ROUND enabled only for host with 2+ ready players; caption "host only · needs 2+ ready".
- This screen is the connection debug view — every socket state is a visible row. A dropped connection just reverts its row to "open slot" (no reconnect logic in scope).

### 1b — Word reveal
- Centered: "YOUR WORD IS" (small caps), the word in a large bordered box with a sage +4/+4 offset shadow, then a 3-2-1 countdown (current digit large in an accent-filled box, upcoming digits smaller/muted).
- Server picks one word and broadcasts; the countdown syncs all clients so the speed bonus is fair.

### 1c — Drawing screen (main)
- Top bar: word (left, bold) · **timer** (right: huge bold, white on accent fill, ink border + offset shadow — the loudest element) · SUBMIT button (accent-2 fill).
- Left toolbar (~106px wide at full scale): tool buttons stacked — PEN·1, PEN·3 (thick pen), FILL, ERASE, UNDO, CLEAR (CLEAR in accent text as a warning); selected tool renders inverted (accent fill, white text). Below, a 2-column swatch grid of the 6 palette colors; selected swatch gets an accent-2 outer ring.
- Canvas: remaining area, white, with a faint grid overlay. **Canvas model: a `cols × rows` int color array** over a 640×480 drawing area. Cell size is a config constant — default **8px → 80×60 grid** (the design's tweak explored 4–20px). Pencil sets cells under mouse drag (PEN·3 = 3×3 stamp), FILL = flood fill, UNDO pops a full-grid snapshot stack, ERASE writes white, CLEAR resets.
- Corner caption on canvas: "grid 80×60 · cell 8px" (derive from constants).
- No live peer view → zero mid-round network traffic. Submitting early banks the remaining seconds as the speed bonus.

### 1d — Sabotage event (optional layer — cut first if short on time)
- Same drawing screen; a centered bordered dialog box: "! COLOR LOCKED !" (accent) + "ben stole ORANGE for 10s".
- The locked swatch renders hatched with an × and is unselectable — implementation is just a per-player "banned color" int with an expiry time.
- Easter egg: one secret cell + secret color chosen per round; filling it exactly = +50 pts, revealed only at results. Both features reuse the draw loop; netcode is one extra event message.

### 1e — Voting
- Title "RANK THE <WORD>S"; hint "click a drawing, then a rank".
- One thumbnail card per opponent (scaled-down render of their grid) with a 24px rank badge on the top-left corner (accent fill when assigned, "?" when not), name + submit time below.
- Your own drawing shown at 45% opacity with a "YOURS" band — not rankable.
- Bottom row: rank chips 1..n-1 to assign, LOCK IN button (accent-2) enabled only when every rank is assigned.
- Networking: after the timer each client sends its full grid once (e.g. 80×60 = 4,800 ints) — the only large message in the game. Server redistributes all grids + collects rankings.

### 1f — Results
- Title "ROUND RESULTS" with sage offset echo; one bordered row per player sorted by total: `#rank name … votes X + speed Y (+ egg 50) TOTAL`. Winner's row gets an accent offset shadow.
- Footnote: easter-egg bonus is revealed only here.
- Buttons: NEXT ROUND (accent) · BACK TO LOBBY (sand/secondary).
- Scoring: vote points (from rank aggregation) + speed bonus (seconds remaining at submit) + easter egg. Itemize the math on screen.

## Interactions & Behavior
- All input via `Graphics.wait_next_event` polling (mouse position + button, keyboard); hit-test rectangles for buttons/swatches.
- Game loop redraws dirty regions or full screen per tick; timer ticks once per second.
- State machine: `Lobby → WordReveal → Drawing → (Submitted, waiting) → Voting → Results → (Lobby | WordReveal)`.

## State Management
- Client: game phase, player list + connection states, word, deadline timestamp, grid (int array array), undo stack, selected tool/color, banned color + expiry, submitted flag, received grids, ranking assignment, scores.
- Server (authoritative): lobby roster, word choice, round deadline, collected grids + submit times, collected rankings, score computation, easter-egg cell/color.
- Wire protocol (suggest a simple line-based or Marshal protocol over Unix sockets): `join`, `ready`, `start(word, deadline)`, `sabotage(color, secs)`, `submit(grid, time_left)`, `grids(all)`, `rank(list)`, `results(scores)`.

## Out of Scope
Reconnect/rehydration, authentication/profiles, live relay of drawings mid-round.

## Assets
None — everything is drawn with Graphics primitives and the built-in font. Word list = any plaintext dictionary file, one word per line.

## Files
- `Drawing Game Storyboard.dc.html` — the six-screen storyboard (open in a browser; screens shown at 60%).
